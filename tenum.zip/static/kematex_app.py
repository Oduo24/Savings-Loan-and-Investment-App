import os
import sys
from flask import Flask, request
from auth import read_access_token
from stkpush import stkpush
import json

sys.path.insert(0, os.path.dirname(__file__))


app = Flask(__name__)

@app.route('/test')
def index():
    return 'Hello, World! This is a basic Flask app.'