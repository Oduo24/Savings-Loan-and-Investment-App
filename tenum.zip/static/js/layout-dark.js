(function($) {
    "use strict"

    new quixSettings({
        version: "dark"
    });


})(jQuery);